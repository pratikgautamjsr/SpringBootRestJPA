package org.cap.demo.dao;

import java.util.List;

import org.cap.demo.model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository("employeeDBDao")
public interface IEmployeeDao extends JpaRepository<Employee, Integer> {

	public List<Employee> findByFirstName(String firstName);

	public List<Employee> findByLastName(String lastName);

	public List<Employee> findByFirstNameContaining(String subString);

	public List<Employee> findByLastNameContaining(String subString);

	@Query("FROM Employee e WHERE e.firstName LIKE %:subString%")
	public List<Employee> filterByFirstNameLike(@Param("subString") String subString);

	@Query("FROM Employee e WHERE e.lastName LIKE %:subString%")
	public List<Employee> filterByLastNameLike(@Param("subString") String subString);

	// @Query(value = "SELECT * FROM Employee ORDER BY first_name", nativeQuery =
	// true)
	@Query(value = "FROM Employee ORDER BY firstName")
	public List<Employee> sortByFirstNameAsc();

	public List<Employee> findAllByOrderByFirstName();

	// @Query(value = "SELECT * FROM Employee ORDER BY first_name DESC", nativeQuery
	// = true)
	@Query(value = "FROM Employee ORDER BY firstName DESC")
	public List<Employee> sortByFirstNameDesc();

	public List<Employee> findAllByOrderByFirstNameDesc();

	// @Query(value = "SELECT * FROM Employee ORDER BY last_name", nativeQuery =
	// true)
	@Query(value = "FROM Employee ORDER BY lastName")
	public List<Employee> sortByLastNameAsc();

	public List<Employee> findAllByOrderByLastName();

	// @Query(value = "SELECT * FROM Employee ORDER BY last_name DESC", nativeQuery
	// = true)
	@Query(value = "FROM Employee ORDER BY lastName DESC")
	public List<Employee> sortByLastNameDesc();

	public List<Employee> findAllByOrderByLastNameDesc();

	@Query("SELECT SUM(salary) FROM Employee")
	public Long sumOfEmployeesSalary();

	@Query("SELECT MIN(salary) FROM Employee")
	public Double minimumSalary();

	@Query("SELECT MAX(salary) FROM Employee")
	public Double maximumSalary();
}