package org.cap.demo.service;

import java.util.List;

import org.cap.demo.dao.IEmployeeDao;
import org.cap.demo.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("productService")
public class EmployeeServiceImpl implements IEmployeeService {

	@Autowired
	private IEmployeeDao employeeDBDao;

	@Override
	public List<Employee> createEmployee(Employee product) {
		employeeDBDao.save(product);
		return getAllEmployees();
	}

	@Override
	public List<Employee> getAllEmployees() {
		return employeeDBDao.findAll();
	}

	@Override
	public Employee findEmployee(Integer employeeId) {
		return employeeDBDao.getOne(employeeId);
	}

	@Override
	public List<Employee> updateEmployee(Employee employee) {
		employeeDBDao.save(employee);
		return getAllEmployees();
	}

	@Override
	public List<Employee> deleteEmployee(Integer employeeId) {
		Employee product = employeeDBDao.getOne(employeeId);
		employeeDBDao.delete(product);
		return getAllEmployees();
	}

	@Override
	public List<Employee> findByFirstName(String firstName) {
		return employeeDBDao.findByFirstName(firstName);
	}

	@Override
	public List<Employee> findByLastName(String lastName) {
		return employeeDBDao.findByLastName(lastName);
	}

	@Override
	public List<Employee> findByFirstNameContaining(String subString) {
		return employeeDBDao.findByFirstNameContaining(subString);
	}

	@Override
	public List<Employee> findByLastNameContaining(String subString) {
		return employeeDBDao.findByLastNameContaining(subString);
	}

	@Override
	public List<Employee> filterByFirstNameLike(String subString) {
		return employeeDBDao.filterByFirstNameLike(subString);
	}

	@Override
	public List<Employee> filterByLastNameLike(String subString) {
		return employeeDBDao.filterByLastNameLike(subString);
	}

	@Override
	public List<Employee> sortByFirstNameAsc() {
		return employeeDBDao.sortByFirstNameAsc();
		// return employeeDBDao.findAllByOrderByFirstName();
	}

	@Override
	public List<Employee> sortByFirstNameDesc() {
		return employeeDBDao.sortByFirstNameDesc();
		// return employeeDBDao.findAllByOrderByFirstNameDesc();
	}

	@Override
	public List<Employee> sortByLastNameAsc() {
		return employeeDBDao.sortByLastNameAsc();
	}

	@Override
	public List<Employee> sortByLastNameDesc() {
		return employeeDBDao.sortByLastNameDesc();
	}

	public Long sumOfEmployeesSalary() {
		return employeeDBDao.sumOfEmployeesSalary();
	}

	@Override
	public Double minimumSalary() {
		return employeeDBDao.minimumSalary();
	}

	@Override
	public Double maximumSalary() {
		return employeeDBDao.maximumSalary();
	}
}