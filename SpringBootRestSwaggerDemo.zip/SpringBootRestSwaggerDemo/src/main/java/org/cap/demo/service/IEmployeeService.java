package org.cap.demo.service;

import java.util.List;

import org.cap.demo.model.Employee;

public interface IEmployeeService {

	public List<Employee> createEmployee(Employee employee);

	public List<Employee> getAllEmployees();

	public Employee findEmployee(Integer employeeId);

	public List<Employee> updateEmployee(Employee employee);

	public List<Employee> deleteEmployee(Integer employeeId);

	public List<Employee> findByFirstName(String firstName);

	public List<Employee> findByLastName(String lastName);

	public List<Employee> findByFirstNameContaining(String subString);

	public List<Employee> findByLastNameContaining(String subString);

	public List<Employee> filterByFirstNameLike(String subString);

	public List<Employee> filterByLastNameLike(String subString);

	public List<Employee> sortByFirstNameAsc();

	public List<Employee> sortByFirstNameDesc();

	public List<Employee> sortByLastNameAsc();

	public List<Employee> sortByLastNameDesc();

	public Long sumOfEmployeesSalary();

	public Double minimumSalary();

	public Double maximumSalary();
}
