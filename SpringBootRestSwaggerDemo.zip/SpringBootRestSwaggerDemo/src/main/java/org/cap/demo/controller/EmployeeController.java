package org.cap.demo.controller;

import java.util.List;

import org.cap.demo.model.Employee;
import org.cap.demo.service.IEmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/app/v0")
@SuppressWarnings({ "unchecked", "rawtypes" })
public class EmployeeController {

	@Autowired
	private IEmployeeService employeeService;

	@PostMapping("/employees")
	public ResponseEntity<List<Employee>> createEmployee(@RequestBody Employee employee) {

		List<Employee> employees = employeeService.createEmployee(employee);

		if (employees == null || employees.isEmpty()) {
			return new ResponseEntity("Sorry! Insertion Failed!", HttpStatus.BAD_REQUEST);
		}

		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);

	}

	@GetMapping("/employees")
	public ResponseEntity<List<Employee>> getAllEmployees() {

		List<Employee> employees = employeeService.getAllEmployees();

		if (employees == null || employees.isEmpty()) {
			return new ResponseEntity("Sorry! No Employee available!", HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}

	@GetMapping("/employees/{employeeId}")
	public ResponseEntity<Employee> findEmployee(@PathVariable("employeeId") Integer employeeId) {

		Employee product = employeeService.findEmployee(employeeId);

		if (product == null) {
			return new ResponseEntity("Sorry! Product ID doesn't exists!", HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<Employee>(product, HttpStatus.OK);
	}

	@PutMapping("/employees")
	public ResponseEntity<List<Employee>> updateEmployee(@RequestBody Employee employee) {

		// Product prod = productService.findProduct(product.getProductId());

		// prod = product;

		List<Employee> products = employeeService.updateEmployee(employee);

		if (products == null || products.isEmpty()) {
			return new ResponseEntity("Sorry! Updation Failed!", HttpStatus.BAD_REQUEST);
		}

		return new ResponseEntity<List<Employee>>(products, HttpStatus.OK);

	}

	@DeleteMapping("/employees/{employeeId}")
	public ResponseEntity<List<Employee>> deleteProduct(@PathVariable("employeeId") Integer employeeId) {

		List<Employee> employees = employeeService.deleteEmployee(employeeId);

		if (employees == null || employees.isEmpty()) {
			return new ResponseEntity("Sorry! Employee ID doesn't exists!", HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}

	@GetMapping("/findByFirstName/{firstName}")
	public ResponseEntity<List<Employee>> findByFirstName(@PathVariable("firstName") String firstName) {

		List<Employee> employees = employeeService.findByFirstName(firstName);

		if (employees == null || employees.isEmpty()) {
			return new ResponseEntity("Sorry! No Employees available!", HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}

	@GetMapping("/findByLastName/{lastName}")
	public ResponseEntity<List<Employee>> findByLastName(@PathVariable("lastName") String lastName) {

		List<Employee> employees = employeeService.findByLastName(lastName);

		if (employees == null || employees.isEmpty()) {
			return new ResponseEntity("Sorry! No Employees available!", HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}

	@GetMapping("/findByFirstNameContaining/{subString}")
	public ResponseEntity<List<Employee>> findByFirstNameContaining(@PathVariable("subString") String subString) {

		List<Employee> employees = employeeService.findByFirstNameContaining(subString);

		if (employees == null || employees.isEmpty()) {
			return new ResponseEntity("Sorry! No Employees available!", HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}

	@GetMapping("/findByLastNameContaining/{subString}")
	public ResponseEntity<List<Employee>> findByLastNameContaining(@PathVariable("subString") String subString) {

		List<Employee> employees = employeeService.findByLastNameContaining(subString);

		if (employees == null || employees.isEmpty()) {
			return new ResponseEntity("Sorry! No Employees available!", HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}

	@GetMapping("/filterByFirstNameLike/{subString}")
	public ResponseEntity<List<Employee>> filterByFirstNameLike(@PathVariable("subString") String subString) {

		List<Employee> employees = employeeService.filterByFirstNameLike(subString);

		if (employees == null || employees.isEmpty()) {
			return new ResponseEntity("Sorry! No Employees available!", HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}

	@GetMapping("/filterByLastNameLike/{subString}")
	public ResponseEntity<List<Employee>> filterByLastNameLike(@PathVariable("subString") String subString) {

		List<Employee> employees = employeeService.filterByLastNameLike(subString);

		if (employees == null || employees.isEmpty()) {
			return new ResponseEntity("Sorry! No Employees available!", HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}

	@GetMapping("/sortByFirstNameAsc")
	public ResponseEntity<List<Employee>> sortByFirstNameAsc() {

		List<Employee> employees = employeeService.sortByFirstNameAsc();

		if (employees == null || employees.isEmpty()) {
			return new ResponseEntity("Sorry! No Employees available!", HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}

	@GetMapping("/sortByFirstNameDesc")
	public ResponseEntity<List<Employee>> sortByFirstNameDesc() {

		List<Employee> employees = employeeService.sortByFirstNameDesc();

		if (employees == null || employees.isEmpty()) {
			return new ResponseEntity("Sorry! No Employees available!", HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}

	@GetMapping("/sortByLastNameAsc")
	public ResponseEntity<List<Employee>> sortByLastNameAsc() {

		List<Employee> employees = employeeService.sortByLastNameAsc();

		if (employees == null || employees.isEmpty()) {
			return new ResponseEntity("Sorry! No Employees available!", HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}

	@GetMapping("/sortByLastNameDesc")
	public ResponseEntity<List<Employee>> sortByLastNameDesc() {

		List<Employee> employees = employeeService.sortByLastNameDesc();

		if (employees == null || employees.isEmpty()) {
			return new ResponseEntity("Sorry! No Employees available!", HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}

	@GetMapping("/sumOfEmployeesSalary")
	public ResponseEntity<Long> sumOfEmployeesSalary() {

		Long sumOfSalaries = employeeService.sumOfEmployeesSalary();

		if (sumOfSalaries == null || sumOfSalaries == 0) {
			return new ResponseEntity("Sorry! No Products available!", HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<Long>(sumOfSalaries, HttpStatus.OK);
	}

	@GetMapping("/minimumSalary")
	public ResponseEntity<Double> minimumSalary() {

		Double minimumSalary = employeeService.minimumSalary();

		if (minimumSalary == null || minimumSalary == 0) {
			return new ResponseEntity("Sorry! No Products available!", HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<Double>(minimumSalary, HttpStatus.OK);
	}

	@GetMapping("/maximumSalary")
	public ResponseEntity<Double> maximumSalary() {

		Double maximumSalary = employeeService.maximumSalary();

		if (maximumSalary == null || maximumSalary == 0) {
			return new ResponseEntity("Sorry! No Products available!", HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<Double>(maximumSalary, HttpStatus.OK);
	}
}