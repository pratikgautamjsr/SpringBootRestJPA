package org.cap.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRestSwaggerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRestSwaggerApplication.class, args);
	}

}
